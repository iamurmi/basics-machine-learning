# BASICS-MACHINE-LEARNING
1)Basics python part1
2) Finish python
Next day Numpy
3)Numpy
4)Matplotlib
